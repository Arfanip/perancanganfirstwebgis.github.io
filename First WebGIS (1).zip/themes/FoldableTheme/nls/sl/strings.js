define({
  "_themeLabel": "Zloženka",
  "_layout_default": "Privzeta postavitev",
  "_layout_layout1": "Postavitev 1"
});