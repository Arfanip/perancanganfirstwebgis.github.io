define({
  "_themeLabel": "Tema Foldable",
  "_layout_default": "Tata letak default",
  "_layout_layout1": "Tata Letak 1"
});