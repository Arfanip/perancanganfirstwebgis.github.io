define({
  "_widgetLabel": "Ovládač hlavičky",
  "signin": "Prihlásiť sa",
  "signout": "Odhlásiť sa",
  "about": "Informácie",
  "signInTo": "Prihlásiť sa do",
  "cantSignOutTip": "Táto funkcia sa nedá použiť v režime náhľadu.",
  "more": "viac"
});